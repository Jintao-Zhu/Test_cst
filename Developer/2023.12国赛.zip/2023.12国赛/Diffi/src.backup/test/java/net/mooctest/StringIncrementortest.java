package net.mooctest;

import static org.junit.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.junit.Test;

public class StringIncrementortest {
	
	@Test
	public void test() throws FileNotFoundException {
		StringIncrementor si0 = new StringIncrementor();
		RelativeString r0 = StringIncrementor.diff(" a", "bbbbbbbbbbbbbbbbbbbbbbbbbbbb");
		//RelativeString r1 = new RelativeString(new FileInputStream("1.txt"));
		assertEquals(si0.patch(" aaaaaaaaaaaa", r0), "bbbbbbbbbbbbbbbbbbbbbbbbbbbb");
		
		
	}

}
