package net.mooctest;

public class IndexedString {

}
