package net.mooctest;

public class ExtBoolArraytest {

}
