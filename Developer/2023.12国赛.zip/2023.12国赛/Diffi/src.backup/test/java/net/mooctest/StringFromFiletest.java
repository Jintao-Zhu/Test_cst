package net.mooctest;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.junit.Test;

public class StringFromFiletest {
	
	@Test
	public void test() throws IOException{
		
		String string = StringFromFile.readString("1.txt");
		System.out.println(string);
		assertEquals("1\r\nb\r\nd\r\n", string);
		
		
	}

}
