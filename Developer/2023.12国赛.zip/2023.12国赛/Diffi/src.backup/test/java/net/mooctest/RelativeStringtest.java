package net.mooctest;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import org.junit.Test;

public class RelativeStringtest {
	
	@Test
	public void test() throws FileNotFoundException {
		RelativeString relativeString = new RelativeString();
		
		RelativeString relativeString2 = new RelativeString(new ByteArrayInputStream(new byte[] {'1','\n','2'}));
		
		System.out.println(relativeString.getAbsolute());
		System.out.println(relativeString2.getAbsolute());
		
		relativeString.setAbsolute("awgr");
		
		assertEquals("awgr", relativeString.getAbsolute());

		assertEquals(0, relativeString.linksCount());
		assertEquals(0, relativeString2.linksCount());
		
		
//		System.out.println(relativeString.getLink(0));
//		System.out.println(relativeString2.getLink(1));
		assertEquals(relativeString.toString(), "0 links, 4 absolute chars (12 Bytes ^= --8Bytes)");
		assertEquals(relativeString2.toString(), "0 links, 0 absolute chars (8 Bytes ^= --8Bytes)");
		
		relativeString.debugPrint();
		relativeString2.debugPrint();
		
//		relativeString.bytesToStream(null);
//		relativeString2.bytesToStream(null);
		
		assertEquals(4, relativeString.getLength());
		assertEquals(0, relativeString2.getLength());
		

	}

}
