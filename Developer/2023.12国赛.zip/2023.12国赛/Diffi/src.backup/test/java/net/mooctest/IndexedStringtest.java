package net.mooctest;

import org.junit.Test;

public class IndexedStringtest {
	
	@Test
	public void test() {
		try {
			FileDiffPatch.createPatch("aaa", "bbb", "ccc");
			FileDiffPatch.createPatch("1.txt", "2.txt", null, true);
			FileDiffPatch.doPatch("1.txt", "2.txt", "ccc");
			FileDiffPatch.doPatch("1.txt", "2.txt", null, true);
		
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}
