package net.mooctest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class Optiontest {
	
	@Test
	public void test() {
		Option option0 = new Option("aa");
		Option option1 = new Option("cc", "11");
		Option option2 = new Option("bb", true, "11", "22");
		Option option3 = new Option("dd", "ee", true, "11", "22");
		
		assertEquals("ee", option3.getBeschriebung());
		assertEquals("11", option3.getDelim());
		assertTrue(option3.isHasArg());
		assertFalse(option1.isHasArg());
		
		assertEquals("dd", option3.getName());
		
		assertEquals("22", option3.getDefaultv());

		assertFalse(option3.isIsSet());
		
		try {
			option3.getValue();
		} catch (Exception e) {}
		try {
			option0.getValue();
		} catch (Exception e) {}

		option3.parse("111111111111");
		option1.parse("11111111111");
		assertEquals("1111111", option3.getValue());
		assertFalse(option3.is("bbb"));
		
		
		Diffi diffi = new Diffi(option2, option3);
		
		diffi.addOption(option1);
		
		diffi.parse(new String[] {"aa","bb","cc","dd"});
		
		
		IndexedString iString = new IndexedString("aeeeste");
		
		assertEquals(-1, iString.indexOf(new char[] {'a','e','s','e','t','e'}));
		
		
		
		
		
		
		
		
	}

}
