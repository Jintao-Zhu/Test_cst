package net.mooctest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class StringLinktest {
	@Test
	public void test0() {
		StringLink st0 = new StringLink(0, 1, 5);
		StringLink st1 = new StringLink(new byte[] {'1','2','3'});
		
		assertEquals(5, st0.getLen());
		assertEquals(0, st1.getLen());

		assertEquals(1, st0.getPosNew());
		assertEquals(0, st1.getPosNew());
		assertEquals(0, st0.getPosOrig());
		assertEquals(0, st1.getPosOrig());
		
		assertEquals("{5: 0-->1}", st0.toString());
		
		assertEquals("{0: 0-->0}", st1.toString());

		byte[] by0 = st0.toBytes();
		byte[] by1 = st1.toBytes();
		
		
		for (int i = 0; i < 3; i++) {
			assertEquals(0, by0[i]);
		}
		assertEquals(5, by0[3]);
		for (int i = 4; i < 11; i++) {
			assertEquals(0, by0[i]);
		}
		assertEquals(1, by0[11]);
		
	}

}
