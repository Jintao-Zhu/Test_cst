package net.mooctest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import java.io.*;
import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

public class Httpheaderstest {

    @Test
    public void test0() throws IOException, NoSuchFieldException, IllegalAccessException {
        


    }

}


        
        
        
        

        
        
        

        
              
              
              

        
          
        
        
        
        
        
        
        

        

    