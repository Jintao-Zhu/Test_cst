-- 服务器接口

function entry()

  -- 报头错误的数据包
  write_msg(channels.COM, protocols.Prot_server_send, {cmd_type=1,header=0x5511})
  etimer.delay(1000)
  local res = ask("yesno",{title='提示', msg='请确认被测件是否开始借出，点击“取出”以继续', default=false})
	check(not res, "包头错误有丢包处理，正确", "包头错误没有丢包处理，错误")


  exit()
end

