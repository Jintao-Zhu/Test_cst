-- 读码器接口

function entry()

  -- 报头错误的数据包
  write_msg(channels.COM, protocols.Prot_scanner_send, {cmd_type=1,header=0xAA11})
  etimer.delay(1000)
  local res = ask("yesno",{title='1提示', msg='请确认被测件是否完成归还，点击“归还，插入”以继续', default=false})
	check(not res, "包头错误有丢包处理，正确", "包头错误没有丢包处理，错误")


  exit()
end

