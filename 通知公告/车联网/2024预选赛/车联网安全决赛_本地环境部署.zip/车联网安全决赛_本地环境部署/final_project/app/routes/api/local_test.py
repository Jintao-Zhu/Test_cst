# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：
   Description :
   Author :       Ticpsh
   date：
-------------------------------------------------
"""
import json
import os.path
import time
from typing import Union, Any
import requests
import pandas as pd
from fastapi import APIRouter
from starlette.responses import FileResponse

from app.config.Config import \
    all_log_path, display_log_path, host, \
    port, script_path, testcase_csv_path, parameter_csv_path, files_path
from app.config.error_code import ErrorCode
from app.core.schema.local import LocalTestCaseModel, LocalBaseModel, LocalLanguageModel, FileDownloadBaseModel
from app.core.schema.response_model import FailedResponse
from app.core.schema.response_model import SuccessResponse
from app.core.service.script_exec import process_popen
from app.utils.case_observer import Observer
from app.utils.file_manager import FileOperator

router = APIRouter(
    prefix="",
    tags=["local_tester用例接口"],
    responses={404: {"description": "Not found"}}
)


# 用例同步
@router.get("/local/test/synchronization", description="用例同步", status_code=200, response_model=SuccessResponse)
async def local_synchronization() -> SuccessResponse:
    json_result = FileOperator.synchronization(testcase_csv_path, parameter_csv_path)
    return SuccessResponse(data=json_result)


# 用例启动
@router.post("/local/test/start", description="启动指定id的测试用例", status_code=200,
             response_model=Union[SuccessResponse, FailedResponse])
async def local_start(local_param: LocalTestCaseModel) -> Union[SuccessResponse, FailedResponse]:
    try:
        # 获取参数，查看需要执行的用例Code
        test_case_id = local_param.testCaseId

        # 获取记录编号
        performed_id = str(local_param.performedId)

        # 获取语言
        language = local_param.language

        # 获取参数
        params = local_param.params

        # 根据用例code执行对应的测试用例，根据命名规则对code进行截取
        script_name = "run.py"
        exec_script = os.path.join(script_path, script_name)
        # 将得到的脚本名称与script_path以及.py或.pyc拼接，存在任何一种文件都可以
        # 执行exec_script脚本
        pid = process_popen(exec_script, params, test_case_id, performed_id, language)
        # 通过TestCaseManager调用相应的用例
        return SuccessResponse(message="执行成功", data="pid:{}".format(str(pid)))
    except Exception as e:
        return FailedResponse(message=str(e), data=ErrorCode.INTERNAL_SERVER_ERROR.value)


# 用例停止
@router.post("/local/test/stop", description="停止指定code的测试用例", status_code=200,
             response_model=Union[SuccessResponse, FailedResponse])
async def local_stop(local_param: LocalTestCaseModel, fcntl=None) -> Union[SuccessResponse, FailedResponse]:
    # 获取参数，查看需要执行的用例Code
    test_case_id = local_param.testCaseId
    # 获取记录编号
    performed_id = str(local_param.performedId)
    # 获取params
    params = local_param.params
    # 获取是跳过还是终止
    status = params['status']

    FileOperator.update_status(test_case_id, performed_id, status)

    # 打开一个临时文件记录停止状态
    observer = Observer(test_case_id, performed_id)
    case_status = observer.observe_for_interface()
    if not case_status:
        return FailedResponse(message="用例并未执行！", data=ErrorCode.INTERNAL_SERVER_ERROR.value)
    if case_status == "COMPLETED":
        return FailedResponse(message="用例已执行完毕！", data=ErrorCode.INTERNAL_SERVER_ERROR.value)
    if case_status == "RUNNING":
        observer.stop_observer(status)
        timeout = 30
        start_time = time.time()
        while os.path.exists(observer.observer_path):
            if time.time() - start_time > timeout:
                # log_name = test_case_id + '_' + performed_id + '.log'
                # log_manager = LogManager(log_name, "System Security")
                # log_manager.add_all("ERROR", "用例停止失败，超时！")
                return SuccessResponse(message="当前用例暂时无法停止，停止操作将移至后台进行！")
            continue
        time.sleep(2)
        return SuccessResponse(message="停止成功")


# 用例执行进度
@router.post("/local/test/performed", description="用例执行进度", status_code=200,
             response_model=Union[SuccessResponse, FailedResponse])
async def local_performed(local_param: LocalBaseModel) -> Union[SuccessResponse, FailedResponse]:
    # 获取参数，查看需要执行的用例Code
    test_case_id = local_param.testCaseId
    # 获取记录编号
    performed_id = str(local_param.performedId)
    print('test_case_id:', test_case_id)
    print('performed_id:', performed_id)
    # 根据test_case_id和performedId在status_csv中查找对应行的status并返回
    status = FileOperator.get_status(test_case_id, performed_id)
    # 如果没有找到对应的进程，则返回错误
    if not status:
        return FailedResponse(message='找不到对应的用例', error_code=ErrorCode.PROCESS_NOT_FOUND.value)
    # 如果status为‘执行中’或'已停止'，则返回0
    if status == 'EXEC' or status == 'ERROR' or status == 'STOP' or status == 'SKIP':
        return SuccessResponse(message="查询成功", data="0")
    # 如果status为‘已完成’，则返回100
    else:
        return SuccessResponse(message="查询成功", data="100")


# 用例进行中的记录消息通知
@router.post("/local/test/execution/message", description="获取用例进行中的记录消息通知", status_code=200,
             response_model=Union[SuccessResponse, FailedResponse])
async def local_execution_message(local_param: LocalLanguageModel) -> Union[SuccessResponse, FailedResponse]:
    # 获取参数，查看需要执行的用例Code
    test_case_id = local_param.testCaseId
    # 获取记录编号
    performed_id = local_param.performedId
    # 获取语言
    language = local_param.language

    prefix = language
    # 获取脚本名称
    script_name = test_case_id + '_' + performed_id + '_' + prefix
    # 根据all_log_path获取当前执行的日志文件
    log_name = os.path.join(display_log_path, script_name + '.log')
    # 判断文件是否存在
    if os.path.exists(log_name) is False:
        time.sleep(2)
        if os.path.exists(log_name) is False:
            script_name = test_case_id + '_' + performed_id + ".log"
            log_name_old = os.path.join(display_log_path, script_name)
            if os.path.exists(log_name_old) is False:
                return FailedResponse(message="文件不存在", data=ErrorCode.FILE_NOT_FOUND.value)
            else:
                log_name = log_name_old
    # 读取文件内容，将内容按行分割，存入一个列表中
    with open(log_name, 'r', encoding='utf-8') as f:
        lines = [line.strip() for line in f.readlines()]
    f.close()
    # 返回列表
    return SuccessResponse(message="查询成功", data=lines)


# 用例执行完成后的执行日志
@router.post("/local/test/execution/finish/log", description="获取用例执行完成后的执行日志", status_code=200,
             response_model=Union[SuccessResponse, FailedResponse])
async def local_execution_finish_log(local_param: LocalLanguageModel) -> Union[SuccessResponse, FailedResponse]:
    # 获取参数，查看需要执行的用例Code
    test_case_id = local_param.testCaseId
    # 获取记录编号
    performed_id = local_param.performedId

    # 获取脚本名称
    script_name_cn = test_case_id + '_' + performed_id + '_cn.log'
    script_name_en = test_case_id + '_' + performed_id + '_en.log'
    script_name_old = test_case_id + '_' + performed_id + '.log'
    # 构造下载url
    download_url_cn = f'http://{host}:{port}/download/logs/all_log/{script_name_cn}'
    download_url_en = f'http://{host}:{port}/download/logs/all_log/{script_name_en}'
    download_url_old = f'http://{host}:{port}/download/logs/all_log/{script_name_old}'
    # 判断文件是否存在
    if os.path.exists(os.path.join(all_log_path, script_name_cn)) and os.path.exists(
            os.path.join(all_log_path, script_name_en)):
        # 返回日志文件供下载
        return SuccessResponse(data=[download_url_cn, download_url_en])
    elif os.path.exists(os.path.join(all_log_path, script_name_old)):
        return SuccessResponse(data=[download_url_old])
    else:
        return FailedResponse(message="文件不存在", data=ErrorCode.INTERNAL_SERVER_ERROR_FILE_NOT_FOUND.value)


# 通过url下载日志文件
@router.get("/download/logs/all_log/{file_name}", description="通过url下载全日志文件", status_code=200,
            response_model=None)
async def local_execution_finish_log_download(file_name: str) -> Any:
    try:
        file_path = os.path.join(all_log_path, file_name)
        return FileResponse(file_path, media_type='application/octet-stream', filename=file_name)
    except Exception as e:
        return FailedResponse(data=ErrorCode.INTERNAL_SERVER_ERROR_FILE_NOT_FOUND.value, message=str(e))


# 用例执行中的执行日志
@router.post("/local/test/execution/status/log", description="获取用例执行完成后的执行日志", status_code=200,
             response_model=Union[SuccessResponse, FailedResponse])
async def local_execution_display_log(local_param: LocalBaseModel) -> Union[SuccessResponse, FailedResponse]:
    # 获取参数，查看需要执行的用例Code
    test_case_id = local_param.testCaseId
    # 获取记录编号
    performed_id = local_param.performedId
    # 获取脚本名称
    script_name = test_case_id + '_' + performed_id
    # 构造下载url
    download_url = f'http://{host}:{port}/download/logs/display_log/{script_name}.log'
    # 判断文件是否存在
    # 判断文件是否存在
    if os.path.exists(os.path.join(all_log_path, script_name + '.log')) is False:
        return FailedResponse(message="文件不存在", data=ErrorCode.INTERNAL_SERVER_ERROR_FILE_NOT_FOUND.value)
    # 返回日志文件供下载
    return SuccessResponse(data=download_url)


# 通过url下载日志文件
@router.get("/download/logs/display_log/{file_name}", description="通过url下载展示日志文件", status_code=200,
            response_model=None)
async def local_execution_display_log_download(file_name: str) -> Any:
    try:
        file_path = os.path.join(display_log_path, file_name)
        return FileResponse(file_path, media_type='application/octet-stream', filename=file_name)
    except Exception as e:
        return FailedResponse(data=ErrorCode.INTERNAL_SERVER_ERROR_FILE_NOT_FOUND.value, message=str(e))




# 用例执行状态消息通知
@router.post("/local/test/execution/status/message", description="获取用例执行状态消息通知", status_code=200,
             response_model=Union[SuccessResponse, FailedResponse])
async def local_execution_status_message(local_param: LocalBaseModel) -> Union[SuccessResponse, FailedResponse]:
    # 获取参数，查看需要执行的用例Code
    test_case_id = local_param.testCaseId
    # 获取记录编号
    performed_id = str(local_param.performedId)
    # 根据test_case_id和performedId在status_csv中查找对应行的status并返回
    status = FileOperator.get_status(test_case_id, performed_id)
    if not status:
        return FailedResponse(message='找不到对应的用例', data=ErrorCode.PROCESS_NOT_FOUND.value)
    return SuccessResponse(message="查询成功", data=status)






# 获取文件传输地址下载文件
@router.post("/local/test/file/st/path", description="下载指定文件", status_code=200,
             response_model=Union[SuccessResponse, FailedResponse])
async def download_file(local_param: FileDownloadBaseModel) -> Union[SuccessResponse, FailedResponse]:
    # 获取参数
    test_case_id = local_param.testCaseId
    performed_id = str(local_param.performedId)
    file_url = local_param.params.filePath
    file_name = local_param.params.fileName  # 获取指定的文件名
    
    try:
        # 发起文件下载请求
        response = requests.get(file_url, stream=True)
        response.raise_for_status()  # 检查请求是否成功

        # 将文件保存到指定路径
        with open(os.path.join(script_path, file_name), "wb") as file:  
            for chunk in response.iter_content(chunk_size=8192):
                file.write(chunk)

        return SuccessResponse(message="文件下载成功", data="1")
    
    except requests.exceptions.RequestException as e:
        # 捕获下载错误
        return FailedResponse(message="文件下载失败", data="0")