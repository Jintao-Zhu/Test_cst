# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     
   Description :   
   Author :       Ticpsh
   date：          
-------------------------------------------------
"""

from fastapi import APIRouter
from app.routes.api import local_test

router = APIRouter()
router.include_router(local_test.router)