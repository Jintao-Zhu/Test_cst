# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     run.py
   Description :
   Author :        Ticpsh
   date：          2023/6/27
-------------------------------------------------
"""
import importlib
import os
import sys
import time

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))


def import_class(module_name, class_name):
    try:
        module = importlib.import_module(module_name)
        class_obj = getattr(module, class_name)
        return class_obj
    except (ImportError, AttributeError) as e:
        print(e)
        return None


if __name__ == '__main__':
    input_test_case_id = sys.argv[1]
    input_performed_id = sys.argv[2]
    input_params = sys.argv[3]
    language = sys.argv[4]

    class_name = input_test_case_id
    module_name = 'app.assets.scripts.' + class_name
    test_case = import_class(module_name, class_name)

    try:
        case_result = test_case(input_test_case_id, input_performed_id, input_params, language)
    except TypeError:
        case_result = test_case(input_test_case_id, input_performed_id, input_params)
    time.sleep(2)
    print(case_result)
