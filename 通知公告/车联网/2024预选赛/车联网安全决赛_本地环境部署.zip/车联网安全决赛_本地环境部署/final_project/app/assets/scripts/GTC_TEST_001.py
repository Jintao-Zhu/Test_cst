# -*- coding: utf-8 -*-
import os
import sys
import time
import subprocess
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
from app.utils.log_manager_backup import LogManager

def finalize_exec(log_manager, exec_result):
    if exec_result == "OK":
        log_manager.add_all(exec_result, "执行成功")
    elif exec_result == "NOK":
        log_manager.add_all(exec_result, "执行失败")
    elif exec_result == "ERROR":
        log_manager.add_all(exec_result, "执行异常，请检查问题后再次执行！")
    else:
        log_manager.add_all("ERROR", "无该状态，请检查脚本后修改，保证运行结果状态有效！")
    log_manager.add_all("INFO", "------------------------- 执行脚本结束 -------------------------")


def GTC_TEST_001(test_case_id_local, performed_id_local, params_local):
    log_name = test_case_id_local + '_' + performed_id_local + '.log'
    log_manager = LogManager(log_name, "model name")
    exec_result = "NOK"

    try:
        log_manager.add_all("INFO", "------------------------- 执行脚本开始 -------------------------")
        log_manager.add_all("INFO", "该脚本用于测试python调用命令行功能")
        result = subprocess.run(["which", "python"], capture_output=True, text=True)
        # 输出结果
        if result.returncode == 0:  # 检查命令是否执行成功
            log_manager.add_all("INFO", "Python 路径:%s", result.stdout.strip())
            exec_result = "OK"
        else:
            log_manager.add_all("INFO", "未找到 Python 路径。")
            exec_result = "NOK"

        finalize_exec(log_manager, exec_result)
        return exec_result
    

    except Exception as e:
        log_manager.add_all("ERROR", str(e))
        exec_result = "ERROR"
        finalize_exec(log_manager, exec_result)
        return exec_result





if __name__ == '__main__':
    test_case_id = sys.argv[1]
    performed_id = sys.argv[2]
    params = sys.argv[3]
    exec_result = GTC_TEST_001(test_case_id, performed_id, params)
    time.sleep(2)
    print(exec_result)