# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     
   Description :   
   Author :       Ticpsh
   date：          
-------------------------------------------------
"""
import subprocess
import threading

import pandas as pd

from app.config.Config import status_csv_path, interpreter_path
from app.utils.file_manager import FileOperator


# 通过subprocess.call()方法执行python脚本,阻塞主线程
def start_subprocess(cmd):
    subprocess.run(cmd, shell=True)


# 通过subprocess.Popen()方法执行python脚本,不阻塞主线程，在执行完毕后，获取进程的输出
def process_popen(script, params, test_case_id, performed_id, language):
    # 保存进程输出，配置日志格式
    # 执行命令，拼接参数
    command = [interpreter_path, script, test_case_id, performed_id, str(params), language]
    print(123321)
    print(command)
    process = subprocess.Popen(command, shell=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    pid = str(process.pid)
    # 向status.csv中插入数据
    status_csv = FileOperator.load_csv(status_csv_path)
    new_row = {'testCaseId': test_case_id, 'performedId': performed_id, 'status': 'EXEC'}
    # 在最后一行插入
    status_csv = pd.concat([status_csv, pd.DataFrame([new_row], index=[0])], ignore_index=True)
    FileOperator.write_csv(status_csv, status_csv_path)
    # 通过线程来判断是否执行完毕
    t = threading.Thread(target=save_popen_result, args=(process, test_case_id, performed_id, status_csv))
    t.start()
    return pid


# 保存进程的输出
def save_popen_result(process: subprocess.Popen, test_case_id, performed_id, status_csv):
    # 实时获取process的输出,去除所有引号
    stdout = process.communicate()[0].decode('utf-8').replace('"', '').replace('\n', '').replace('\r', '')
    if 'NOK' in stdout.upper():
        stdout = 'NOK'
    elif 'COK' in stdout.upper():
        stdout = 'COK'
    elif 'OK' in stdout.upper():
        stdout = 'OK'
    elif 'NA' in stdout.upper():
        stdout = 'NA'
    elif 'SKIP' in stdout.upper():
        stdout = 'SKIP'
    elif 'STOP' in stdout.upper():
        stdout = 'STOP'
    else:
        stdout = 'ERROR'
    # 一共六种状态：EXEC、ERROR、OK、NOK、COK、STOP
    # 判断进程是否执行完毕
    if status_csv.loc[(status_csv['testCaseId'] == test_case_id) & (status_csv['performedId'] == performed_id) & (
            status_csv['status'] == 'EXEC'), 'status'].values[0] == 'EXEC':
        FileOperator.update_status(test_case_id, performed_id, stdout)
