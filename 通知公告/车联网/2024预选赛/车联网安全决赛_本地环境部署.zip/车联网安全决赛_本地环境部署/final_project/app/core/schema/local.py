# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     
   Description :   
   Author :       Ticpsh
   date：          
-------------------------------------------------
"""

from pydantic import BaseModel, Field, validator, HttpUrl


class LocalBaseModel(BaseModel):
    # 定义基本post方法输入参数模型
    testCaseId: str = Field(..., title="用例编号", description="用例编号")
    performedId: str = Field(..., title="记录编号", description="记录编号")

    # 定义基本post方法输入参数模型校验器
    @validator('testCaseId')
    def check_test_case_id(cls, v):
        if not v:
            raise ValueError('`testCaseId` 不能为空')
        return v


class LocalLanguageModel(BaseModel):
    # 定义基本post方法输入参数模型
    testCaseId: str = Field(..., title="用例编号", description="用例编号")
    performedId: str = Field(..., title="记录编号", description="记录编号")
    language: str = Field(..., title="语言", description="语言")

    # 定义基本post方法输入参数模型校验器
    @validator('testCaseId')
    def check_test_case_id(cls, v):
        if not v:
            raise ValueError('`testCaseId` 不能为空')
        return v


class LocalTestCaseModel(BaseModel):
    # 定义用例启动输入参数模型
    testCaseId: str = Field(..., title="用例编号", description="用例编号")
    performedId: str = Field(..., title="记录编号", description="记录编号")
    language: str = Field(..., title="语言", description="语言")
    params: dict = Field({}, title="参数", description="参数")

    # 定义用例启动输入参数模型校验器
    @validator('testCaseId')
    def check_test_case_id(cls, v):
        if not v:
            raise ValueError('`testCaseId` 不能为空')
        return v


class LocalTestConclusionModel(BaseModel):
    # 定义用例启动输入参数模型
    testCaseId: str = Field(..., title="用例编号", description="用例编号")
    performedId: str = Field(..., title="记录编号", description="记录编号")
    status: str = Field(..., title="结论状态", description="结论状态")
    remark: str = Field(None, title="备注", description="备注")
    file: list = Field(None, title="文件", description="文件")

    # 定义用例启动输入参数模型校验器
    @validator('testCaseId')
    def check_test_case_id(cls, v):
        if not v:
            raise ValueError('`testCaseId` 不能为空')
        return v

    # 定义用例启动输入参数模型校验器
    @validator('performedId')
    def check_performed_id(cls, v):
        if not v:
            raise ValueError('`performedId` 不能为空')
        return v

    # 定义用例启动输入参数模型校验器
    @validator('status')
    def check_status(cls, v):
        if not v:
            raise ValueError('`status` 不能为空')
        return v


class ParamsModel(BaseModel):
    filePath: HttpUrl = Field(..., title="文件URL", description="文件的下载链接")
    fileName: str = Field(..., title="文件名称", description="下载后保存的文件名")

class FileDownloadBaseModel(BaseModel):
    testCaseId: str = Field(..., title="用例编号", description="用例编号")
    performedId: str = Field(..., title="记录编号", description="记录编号")
    params: ParamsModel