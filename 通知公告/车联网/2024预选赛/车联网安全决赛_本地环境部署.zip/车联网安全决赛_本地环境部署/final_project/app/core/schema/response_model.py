# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     
   Description :   
   Author :        Shaobo Su Ticpsh
   date：          
-------------------------------------------------
"""
from typing import Any

from fastapi import status
from pydantic import BaseModel


class SuccessResponse(BaseModel):
    code: int = status.HTTP_200_OK
    message: str = "成功"
    data: Any = None


class FailedResponse(BaseModel):
    code: int = status.HTTP_500_INTERNAL_SERVER_ERROR
    message: str = "失败"
    data: Any = None
