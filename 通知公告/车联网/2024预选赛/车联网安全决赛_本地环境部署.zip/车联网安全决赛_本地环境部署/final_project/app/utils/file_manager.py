# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     
   Description :   
   Author :       Ticpsh
   date：          
-------------------------------------------------
"""

import fcntl
import json
import os
import sys

import pandas as pd

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from app.config.Config import dyna_loop_csv_path, status_csv_path


class FileOperator:
    def __init__(self):
        pass

    # 写入json文件
    @staticmethod
    def write_json_file(file_path, json_data):
        with open(file_path, 'w') as f:
            json.dump(json_data, f)

    # 将excel内容写入csv文件
    @staticmethod
    def excel_to_csv(file_path, save_path):
        # 读取excel文件
        df = pd.read_excel(file_path)
        # 写入csv文件， 第一行为列名
        df.to_csv(save_path, index=False, header=True)

    @staticmethod
    # 写入csv文件并加锁
    def write_csv(csv_data: pd.DataFrame, save_path):
        csv_data.to_csv(save_path, index=False, header=True, encoding='utf-8')

    # 读取json文件
    @staticmethod
    def read_json_file(file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            json_data = json.load(f)
        return json_data

    # 返回csv文件内容
    @staticmethod
    # 读取csv文件并加锁
    def load_csv(file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)  # 加锁
            csv_file = pd.read_csv(f, index_col=False, keep_default_na=False, encoding='utf-8')
            # 判断是否包含performedID列，若包含则作为str读取
            if 'performedId' in csv_file.columns:
                csv_file['performedId'] = csv_file['performedId'].astype(str)
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)  # 解锁
        return csv_file

    @staticmethod
    def merge_txt(file_list, output_file):
        """
        This function merges multiple text files into a single text file.

        :param file_list: List of file paths to be merged.
        :param output_file: The output file path.
        """
        merged_lines = []
        for file in file_list:
            with open(file, 'r') as f:
                merged_lines.extend(f.readlines())
        with open(output_file, 'w') as f:
            f.writelines(merged_lines)

    @staticmethod
    def update_status(test_case_id, performed_id, status: str):
        status_csv = FileOperator.load_csv(status_csv_path)
        status_csv.loc[
            (status_csv['testCaseId'] == test_case_id) & (
                    status_csv['performedId'] == performed_id), 'status'] = status.upper()
        FileOperator.write_csv(status_csv, status_csv_path)

    @staticmethod
    def get_status(test_case_id, performed_id):
        status_csv = FileOperator.load_csv(status_csv_path)
        return status_csv.loc[
            (status_csv['testCaseId'] == test_case_id) & (status_csv['performedId'] == performed_id), 'status'].values[
            0]

    @staticmethod
    def synchronization(test_case_csv, parameter_csv, dyna_loop_csv=dyna_loop_csv_path):
        # 读取testcase_list.csv，将所有数据转换为字符串，避免读取时将数字转换为float或int
        testcase_list = pd.read_csv(test_case_csv, index_col=False, keep_default_na=False, encoding='utf-8')
        # 将所有数据转换为字符串，避免读取时将数字转换为float或int
        testcase_list = testcase_list.astype(str)
        testcases = {"testcase": []}
        # 读取parameter_list.csv，将所有数据转换为字符串，避免读取时将数字转换为float或int
        parameter_list = pd.read_csv(parameter_csv, index_col=False, keep_default_na=False, encoding='utf-8')
        # 将所有数据转换为字符串，避免读取时将数字转换为float或int
        parameter_list = parameter_list.astype(str)
        # 解析relatedParam，以|分割，生成paramKey列表
        for index, row in testcase_list.iterrows():
            param_keys = row['relatedParam'].split('|')
            if param_keys == ['']:
                # 没有参数，只读取testcase_list.csv中的数据，relatedParam为空，params为[]
                testcase_dict = row.to_dict()
                testcase_dict['params'] = []
                testcases['testcase'].append(testcase_dict)
                continue
            params = []
            for param_key in param_keys:
                # 读取parameter_list.csv中的对应行
                param = parameter_list.loc[parameter_list['paramKey'] == param_key]
                # 如果param的paramValueType值是"dynaLoop"，则读取dyna_loop_csv,将对应paramkey的数据以[{}]写入paramValueTypeEx中
                if param['paramValueType'].values[0] == 'dynaLoop':
                    # 读取paramValueTypeEx，以|分割，生成每个元素都是dyna_loop_csv的paramKey列表
                    dyna_loop_key = param['paramValueTypeExCn'].values[0].split('|')
                    # 读取dyna_loop_csv
                    dyna__csv = pd.read_csv(dyna_loop_csv, index_col=False, keep_default_na=False, encoding='utf-8')
                    # 将所有数据转换为字符串，避免读取时将数字转换为float或int
                    dyna__csv = dyna__csv.astype(str)
                    param = param.copy()
                    # 首先，创建两个列表，用于存储中英文数据
                    dyna_loop_dict_list_cn = []
                    dyna_loop_dict_list_en = []
                    # 遍历dyna_loop_key，将每个元素都是dyna_loop_csv的paramKey列表中的数据读取出来
                    for key in dyna_loop_key:
                        # 创建两个字典用于存储中英文数据
                        dyna_loop_dict_cn = {}
                        dyna_loop_dict_en = {}
                        # 读取dyna_loop_csv中对应paramkey的数据
                        dyna_loop = dyna__csv.loc[dyna__csv['paramKey'] == key]
                        # 将该行数据转换为dict
                        dyna_loop_dict = dyna_loop.to_dict(orient='records')[0]
                        # 如果dyna_loop中dataType是2，那么将dataTemplate列以|分割，生成list，每个元素是字符串，作为dataTemplate的值
                        if dyna_loop['dataType'].values[0] == "2":
                            dyna_loop_dict['dataTemplateCn'] = dyna_loop_dict['dataTemplateCn'].split('|')
                            dyna_loop_dict['dataTemplateEn'] = dyna_loop_dict['dataTemplateEn'].split('|')
                        # 如果字段包含Cn、En，那么将Cn、En的数据分别添加到dyna_loop_dict_cn、dyna_loop_dict_en中，重命名取消Cn、En
                        for k, v in dyna_loop_dict.items():
                            if k.endswith('Cn'):
                                dyna_loop_dict_cn[k[:-2]] = v
                            elif k.endswith('En'):
                                dyna_loop_dict_en[k[:-2]] = v
                            else:
                                dyna_loop_dict_cn[k] = v
                                dyna_loop_dict_en[k] = v
                        # 将dyna_loop_dict_cn、dyna_loop_dict_en添加到dyna_loop_dict_list中
                        dyna_loop_dict_list_cn.append(dyna_loop_dict_cn)
                        dyna_loop_dict_list_en.append(dyna_loop_dict_en)
                    # 将dyna_loop_dict_list_cn、dyna_loop_dict_list_en转换为字符串，作为paramValueTypeExCn、paramValueTypeExEn的值
                    param.loc[param['paramKey'] == param_key, 'paramValueTypeExCn'] = [dyna_loop_dict_list_cn]
                    param.loc[param['paramKey'] == param_key, 'paramValueTypeExEn'] = [dyna_loop_dict_list_en]
                # 将该行数据转换为dict
                param_dict = param.to_dict(orient='records')[0]
                params.append(param_dict)
            # 将该行数据转换为dict
            testcase_dict = row.to_dict()
            # 将params添加到testcase_dict中
            testcase_dict['params'] = params
            # 将testcase_dict添加到testcases中
            testcases['testcase'].append(testcase_dict)

        return testcases


if __name__ == '__main__':
    file_loader = FileOperator()
    data = file_loader.synchronization(
        r"D:\IntelliJ\PycharmProjects\cloud_security\app\assets\csv\testcase_list.csv",
        r"D:\IntelliJ\PycharmProjects\cloud_security\app\assets\csv\parameter_list.csv",
        r"D:\IntelliJ\PycharmProjects\cloud_security\app\assets\csv\dyna_loop.csv")
    # 将data转化成json格式，格式化输出
    data = json.dumps(data, ensure_ascii=False, indent=4)
    print(data)
