# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     
   Description :   
   Author :        Shaobo Su Ticpsh
   date：          
-------------------------------------------------
"""
import fcntl
import os

from app.config.Config import temp_path


class Observer:
    def __init__(self, test_case_id, performed_id):
        self.test_case_id = test_case_id
        self.performed_id = performed_id
        self.file_name = f'{self.test_case_id}_{self.performed_id}.txt'
        self.observer_path = os.path.join(temp_path, self.file_name)

    def create_observer(self):
        # 创建一个临时文件，用于观察是否有停止信号
        with open(self.observer_path, 'w') as f:
            f.write("RUNNING")

    def remove_observer(self):
        if os.path.exists(self.observer_path):
            os.remove(self.observer_path)

    def stop_observer(self, status):
        if os.path.exists(self.observer_path):
            with open(self.observer_path, 'w') as f:
                f.write(status.upper())

    def observe(self):
        stop_status = {"SKIP": "跳过", "STOP": "停止"}
        if os.path.exists(self.observer_path) and os.path.getsize(self.observer_path) > 0:
            with open(self.observer_path, 'r') as f:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX)  # 加锁
                status = f.read().strip()
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)  # 解锁
                if status.upper() in stop_status.keys():
                    # 删除临时文件
                    os.remove(self.observer_path)
                    return stop_status[status.upper()]
                else:
                    return "RUNNING"
        else:
            return "RUNNING"

    def observe_for_interface(self):
        completed_status = {"COMPLETED": "完成"}
        if os.path.exists(self.observer_path) and os.path.getsize(self.observer_path) > 0:
            with open(self.observer_path, 'r') as f:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                status = f.read().strip()
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                if status.upper() in completed_status.keys():
                    os.remove(self.observer_path)
                return status.upper()
        else:
            return ""
