# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：
   Description :
   Author :       Ticpsh
   date：
-------------------------------------------------
"""
import logging
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from app.config.Config import all_log_path, display_log_path, localization_path, languages_path
from app.utils.language_manager import LanguageManager

INFO = logging.INFO
OK = logging.INFO + 1
COK = logging.INFO + 2
ADVICE = logging.INFO + 3
NOK = logging.INFO + 4
NA = logging.INFO + 6
ERROR = logging.ERROR
level_list = ["INFO", "OK", "COK", "ADVICE", "NOK", "NA", "ERROR"]


class LogManager(logging.Logger):
    def __init__(self, log_name, logger_name="Unknown Module", stop_flag=False):
        super(LogManager, self).__init__(logger_name)
        # 添加日志级别
        logging.addLevelName(OK, 'OK')
        logging.addLevelName(COK, 'COK')
        logging.addLevelName(ADVICE, 'ADVICE')
        logging.addLevelName(NOK, 'NOK')
        logging.addLevelName(NA, 'NA')

        # 日志文件名
        self.log_name = log_name
        self.gtc = log_name.rsplit('_', 1)[0]
        self.performed = log_name.rsplit('_', 1)[1].split('.')[0]
        # 模块名
        self.logger_name = logger_name
        # 日志本地化
        self.localization = LanguageManager(os.path.join(localization_path, log_name.rsplit('_', 1)[0] + ".json"))
        # 语言列表
        self.languages = self.localization.load_languages(languages_path)
        self.handlers = []
        self.status_log = []
        self.general_log = []
        # 根据languages生成对应的log文件名列表
        for language in self.languages:
            self.status_log.append(
                os.path.join(display_log_path, f"{self.gtc}_{self.performed}_{language['log_suffix']}.log"))
            self.general_log.append(
                os.path.join(all_log_path, f"{self.gtc}_{self.performed}_{language['log_suffix']}.log"))
        # 判断路径是否存在
        self.log_path_judge()
        # 如果stop_flag为True，则表示需要在原有日志文件中追加日志，否则删除原有日志文件
        if not stop_flag:
            self.log_name_judge()

        # 设置日志的写入格式
        self.default_formatter = logging.Formatter('[%(asctime)s.%(msecs)03d] [%(levelname)s] %(message)s',
                                                   datefmt='%H:%M:%S')
        self.light_formatter = logging.Formatter('%(message)s')

        for language in self.languages:
            # Display log handler
            self.add_handler(display_log_path, f"{self.gtc}_{self.performed}_{language['log_suffix']}.log",
                             self.default_formatter)

            # General log handler
            self.add_handler(all_log_path, f"{self.gtc}_{self.performed}_{language['log_suffix']}.log",
                             self.default_formatter)

    def add_handler(self, path, filename, formatter):
        handler = logging.FileHandler(os.path.join(path, filename), encoding='utf-8')
        handler.setLevel(logging.INFO)
        handler.setFormatter(formatter)
        self.handlers.append(handler)
        self.addHandler(handler)

    @staticmethod
    def log_path_judge():
        """
        判断日志文件夹是否存在，如果不存在则创建
        :return: None
        """
        # 判断是否存在文件夹，如果不存在则创建
        if not os.path.exists(display_log_path):
            os.makedirs(display_log_path)
        if not os.path.exists(all_log_path):
            os.makedirs(all_log_path)

    def log_name_judge(self):
        """
        判断日志文件是否存在，如果存在则删除
        :return: None
        """
        for status_log in self.status_log:
            if os.path.exists(status_log):
                os.remove(status_log)
        for general_log in self.general_log:
            if os.path.exists(general_log):
                os.remove(general_log)

    def add_display(self, log_level, msg, *args, formatter=True):
        """
        仅写入前端日志，不写入全量日志
        :param log_level: 日志等级
        :param msg: 日志内容
        :param args: 日志内容中的占位符
        :param formatter: 是否应用默认格式
        :return: None
        """
        self._write_log(log_level, msg, *args, formatter=formatter, target="display_log")

    def add_record(self, log_level, msg, *args, formatter=True):
        """
        仅写入全量日志，不写入前端日志
        :param log_level: 日志等级
        :param msg: 日志内容
        :param args: 日志内容中的占位符
        :param formatter: 是否应用默认格式
        :return: None
        """
        self._write_log(log_level, msg, *args, formatter=formatter, target="all_log")

    def add_all(self, log_level, msg, *args, formatter=True):
        """
        同时写入前端日志和全量日志
        :param log_level: 日志等级
        :param msg: 日志内容
        :param args: 日志内容中的占位符
        :param formatter: 是否应用默认格式
        :return: None
        """
        self._write_log(log_level, msg, *args, formatter=formatter)

    @staticmethod
    def level_judgement(log_level):
        if log_level in level_list:
            level_num = eval(log_level)
        else:
            level_num = INFO
        return level_num

    def find_handler(self, handler_name, target=None):
        """
        查找handler
        :param handler_name: log_name
        :param target: target="display_log" or target="general_log"
        :return: list of handlers
        """
        match_handlers = []
        if not target:
            for index in self.handlers:
                if index.baseFilename.endswith(handler_name):
                    match_handlers.append(index)
        else:
            for index in self.handlers:
                if index.baseFilename.endswith(handler_name) and target in index.baseFilename:
                    match_handlers.append(index)
        return match_handlers

    def _write_log(self, log_level, msg, *args, formatter=True, target=None):
        """
        写入日志
       :param log_level: 日志等级
        :param msg: 日志内容
        :param args: 日志内容中的占位符
        :param formatter: 是否应用默认格式
        :return: None
        """
        log_level = self.level_judgement(log_level)
        for language in self.languages:
            # 根据msg获取对应的md5值，然后根据md5值获取对应的语言版本
            log_message = self.localization.get_message(msg, lang=language["code"])
            # 如果msg没有对应的语言版本，则使用原始msg
            if not log_message:
                log_message = msg
            # 根据args获取对应的md5值，然后根据md5值获取对应的语言版本
            if '%' in log_message:
                # 创建一个新的列表，用于存储args中的值
                translated_args = []
                for arg in args:
                    arg_message = self.localization.get_message(arg, lang=language["code"])
                    if not arg_message:
                        arg_message = arg
                    translated_args.append(arg_message)
                log_message = log_message % tuple(translated_args)
            handlers = self.find_handler(f"{self.gtc}_{self.performed}_{language['log_suffix']}.log", target=target)
            for matched_handler in handlers:
                if formatter:
                    matched_handler.setFormatter(self.default_formatter)
                else:
                    matched_handler.setFormatter(self.light_formatter)
                matched_handler.emit(
                    logging.makeLogRecord({
                        'name': self.logger_name,
                        'levelname': logging.getLevelName(log_level),
                        'msg': log_message
                    })
                )


if __name__ == '__main__':
    log_manager = LogManager("GTC_SSYS_003_4156314564416332.log", "test")
    log_manager.add_all("ADVICE", "端口: %s\t 状态: %s", "1", "2")
    # local_config = LogLocalization(os.path.join(localization_path, "test.json"))
    # print(local_config.config)
    # print(local_config.get_message("测试", lang="en"))
