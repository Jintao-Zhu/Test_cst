# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     
   Description :   
   Author :        Shaobo Su Ticpsh
   date：          
-------------------------------------------------
"""
import hashlib
import json
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from app.config.Config import localization_path


class LanguageManager:
    def __init__(self, config_path):
        self.config = self.load_config(config_path)

    @staticmethod
    def load_config(config_path):
        if os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as file:
                config = json.load(file)
                return config
        else:
            config = {}
        ###
        public_path = os.path.join(localization_path, "manual.json")
        with open(public_path, 'r', encoding='utf-8') as file:
            public: dict = json.load(file)
        res = public.copy()
        public.update(config)
        ###
        return res

    def get_message(self, msg, lang='cn'):
        md5_msg = hashlib.md5(msg.encode('utf-8')).hexdigest()
        # 根据md5值获取对应的key以及对应的语言版本
        if md5_msg in self.config:
            return self.config[md5_msg][lang]
        else:
            return msg

    @staticmethod
    def load_languages(config_path):
        """
        加载语言列表
        :param config_path: 语言列表配置文件路径
        :return: 语言列表
        """
        with open(config_path, 'r', encoding='utf-8') as config_file:
            config = json.load(config_file)
            return config.get("languages", [])
