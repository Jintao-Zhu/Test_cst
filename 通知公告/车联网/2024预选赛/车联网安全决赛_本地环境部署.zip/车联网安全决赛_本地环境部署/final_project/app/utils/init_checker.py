# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     
   Description :   
   Author :       Ticpsh
   date：          
-------------------------------------------------
"""

import os


def path_checker():
    # 判断logs文件夹是否存在，如果不存在则创建
    if not os.path.exists("logs"):
        os.makedirs("logs")
    # 判断docs文件夹是否存在，如果不存在则创建
    if not os.path.exists("files"):
        os.makedirs("files")
    if not os.path.exists("temp"):
        os.makedirs("temp")
