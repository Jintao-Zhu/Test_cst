#!/usr/bin/env python
# -*- coding:utf-8 -*-

# Error codes map for api errors
# Error codes are divided into 3 parts:
# 1. HTTP status code
# 2. Error type
# 3. Error code
# For example, 40001 means 400 Bad Request, 1 means error type is client error, 1 means error code is 1

from enum import Enum, unique


@unique
class ErrorCode(Enum):
    # 40001: Invalid request
    INVALID_REQUEST = 40001
    # 40002: Invalid parameter
    INVALID_PARAMETER = 40002
    # 40003: Invalid file
    INVALID_FILE = 40003
    # 400031: Invalid file type
    INVALID_FILE_TYPE = 400031
    # 400032: Invalid file content
    INVALID_FILE_CONTENT = 400032
    # 400033: Invalid file name
    INVALID_FILE_NAME = 400033
    # 40034: Invalid file size
    INVALID_FILE_SIZE = 400034
    # 40035: Invalid file path
    INVALID_FILE_PATH = 400035
    # 400036: Invalid file content : file is empty
    FILE_CONTENT_EMPTY = 400036
    # 400037: Invalid file format
    INVALID_FILE_FORMAT = 400037
    # 400038: File download failed
    FILE_DOWNLOAD_FAILED = 400038
    # 40009: data already exist
    DATA_EXISTS = 40009
    # data create failed
    DATA_CREATE_FAILED = 40010
    # delete failed
    DELETE_FAILED = 40011
    # update failed
    UPDATE_FAILED = 40012

    # 40101: Unauthorized
    UNAUTHORIZED = 40101
    # 40102: Unauthorized : invalid token
    UNAUTHORIZED_INVALID_TOKEN = 40102

    # 40301: Forbidden
    FORBIDDEN = 40301
    # 40302: Forbidden : no permission
    FORBIDDEN_NO_PERMISSION = 40302

    # 40401: Not Found
    NOT_FOUND = 40401
    # 40402: Not Found : no such file
    NOT_FOUND_NO_SUCH_FILE = 40402
    # 40403: Not Found : no such directory
    NOT_FOUND_NO_SUCH_DIRECTORY = 40403
    # 40404: Not Found : no such api
    NOT_FOUND_NO_SUCH_API = 40404

    # 40501: Method Not Allowed
    METHOD_NOT_ALLOWED = 40501
    REQUEST_METHOD_ERROR = 40502
    # 40901: Conflict
    CONFLICT = 40901
    # duplicate data
    DUPLICATE_DATA = 40902

    # 41501: Unsupported Media Type
    UNSUPPORTED_MEDIA_TYPE = 41501

    # 50001: Internal Server Error
    INTERNAL_SERVER_ERROR = 50001
    # 50002: Internal Server Error : file not found
    INTERNAL_SERVER_ERROR_FILE_NOT_FOUND = 50002
    # 50003: Internal Server Error : file is empty
    INTERNAL_SERVER_ERROR_FILE_EMPTY = 50003

    # 50004: Script not found
    SCRIPT_NOT_FOUND = 50004

    # 50005: Process Start Failed
    PROCESS_START_FAILED = 50005

    PROCESS_NOT_FOUND = 50006

    # 50007: Process Stop Failed
    PROCESS_STOP_FAILED = 50007

    # 50008: Tool not found
    TOOL_NOT_FOUND = 50008

    def __str__(self):
        return self.name


# Error codes map for SQL errors
@unique
class SQLErrorCode(Enum):
    # 40011: SQL error
    SQL_ERROR = 40011
    # 40012: SQL error : no such table
    NO_SUCH_TABLE = 40012
    # 40013: SQL error : no such column
    NO_SUCH_COLUMN = 40013
    # 40014: SQL error : no such database
    NO_SUCH_DATABASE = 40014
    # 40015: SQL error : no such index
    NO_SUCH_INDEX = 40015
    # 40016: SQL error : data exists
    DATA_EXISTS = 40016
    # 400161: SQL error : function exists
    FUNCTION_EXISTS = 400161
    # 400162: SQL error : assets exists
    ASSET_EXISTS = 400162
    # 400163: SQL error : tara exists
    TARA_EXISTS = 400163
    # 400164: SQL error : hazard_analysis exists
    HAZARD_ANALYSIS_EXISTS = 400164
    # 40017: SQL error : data not found
    DATA_NOT_FOUND = 40017
    # 400171: SQL error : function not found
    FUNCTION_NOT_FOUND = 400171
    # 400172: SQL error : assets not found
    ASSET_NOT_FOUND = 400172
    # 400173: SQL error : tara not found
    TARA_NOT_FOUND = 400173
    # 400174: SQL error : hazard_analysis not found
    HAZARD_ANALYSIS_NOT_FOUND = 400174
    # 40018: SQL error : data is not unique
    DATA_NOT_UNIQUE = 40018
    # 400191: SQL error : failed to create function
    FUNCTION_CREATE_FAILED = 400191
    # 400192: SQL error : failed to create assets
    ASSET_CREATE_FAILED = 400192
    # 400193: SQL error : failed to create tara
    TARA_CREATE_FAILED = 400193
    # 400194: SQL error : failed to create hazard_analysis
    HAZARD_ANALYSIS_CREATE_FAILED = 400194

    # 40019: SQL error : failed to insert data
    FAILED_TO_CREATE_DATA = 40019

    # 40020: SQL error : failed to update data
    FAILED_TO_UPDATE_DATA = 40020

    # 40021: SQL error : failed to delete data
    FAILED_TO_DELETE_DATA = 40021

    # 40022: SQL error : failed to find response data
    RESPONSE_NOT_FOUND = 40022
