import configparser
import os

# Determine the configuration file path
config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.ini")

# Load the configuration
config = configparser.ConfigParser()
config.read(config_path, encoding='UTF-8')

project_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
host = config.get("server", "host")
port = config.getint("server", "port")

testcase_csv_path = os.path.join(project_path, config.get("csv", "testcase_csv_path"))
parameter_csv_path = os.path.join(project_path, config.get("csv", "parameter_csv_path"))
dyna_loop_csv_path = os.path.join(project_path, config.get("csv", "dyna_loop_csv_path"))
status_csv_path = os.path.join(project_path, config.get("csv", "status_csv_path"))
conclusion_csv_path = os.path.join(project_path, config.get("csv", "conclusion_csv_path"))
script_path = os.path.join(project_path, config.get("script", "script_path"))
interpreter_path = os.path.join(config.get("interpreter", "interpreter_path"))
all_log_path = os.path.join(project_path, config.get("log", "all_log_path"))
localization_path = os.path.join(project_path, config.get("languages", "localization_path"))
languages_path = os.path.join(project_path, config.get("languages", "languages_path"))
display_log_path = os.path.join(project_path, config.get("log", "display_log_path"))
files_path = os.path.join(project_path, config.get("files", "files_path"))
temp_path = os.path.join(project_path, config.get("temp", "temp_path"))