from fastapi import FastAPI
import argparse
import uvicorn

from app.config.Config import host, port, status_csv_path
from app.routes.router import router as api_router
from app.utils.file_manager import FileOperator
from app.utils.init_checker import path_checker

# 初始化 FastAPI
app = FastAPI()
app.include_router(api_router, prefix="")
20
# 如果作为主程序运行
if __name__ == '__main__':
    # 读取status.csv文件，将所有状态为进行中的用例状态改为'已停止'
    file_operator = FileOperator()
    status_csv = file_operator.load_csv(status_csv_path)
    status_csv.loc[status_csv['status'] == '执行中', 'status'] = '已停止'
    status_csv.to_csv(status_csv_path, index=False)
    path_checker()

    # 解析命令行参数
    parser = argparse.ArgumentParser(description='Cloud Security')
    parser.add_argument('--host', type=str, default=host, help='host')
    parser.add_argument('--port', type=int, default=port, help='port')

    args = parser.parse_args()
    host = args.host
    port = args.port

    # 启动 FastAPI 应用
    uvicorn.run(app, host=host, port=port)
